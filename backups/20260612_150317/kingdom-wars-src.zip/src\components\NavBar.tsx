import { useGameStore } from '../store/gameStore';
import { useT } from '../i18n/useT';

export default function NavBar() {
  const { activeScreen, setScreen } = useGameStore();
  const t = useT();

  const ROW1 = [
    { key: 'home',     emoji: '🏰', tkey: 'nav_home'        },
    { key: 'repair',   emoji: '🔧', tkey: 'nav_repair'      },
    { key: 'army',     emoji: '⚔️', tkey: 'nav_army'        },
    { key: 'attack',   emoji: '🗡️', tkey: 'nav_attack'      },
  ] as const;

  const ROW2 = [
    { key: 'worldmap',    emoji: '🗺️', tkey: 'nav_worldmap'    },
    { key: 'leaderboard', emoji: '🏆', tkey: 'nav_leaderboard'  },
    { key: 'quests',      emoji: '📋', tkey: 'nav_quests'       },
    { key: 'shop',        emoji: '🛒', tkey: 'nav_shop'         },
  ] as const;

  type TabKey = typeof ROW1[number]['key'] | typeof ROW2[number]['key'];

  const renderTab = ({ key, emoji, tkey }: { key: TabKey; emoji: string; tkey: string }) => {
    // Strip leading emoji + space to get just the text label
    const label = t(tkey).replace(/^[\p{Emoji_Presentation}\p{Extended_Pictographic}]\s*/u, '').trim();
    return (
      <button
        key={key}
        className={`nav-item ${activeScreen === key ? 'active' : ''}`}
        onClick={() => setScreen(key as any)}
        style={{ flex: 1, flexDirection: 'column', gap: 3, padding: '6px 2px' }}
      >
        <span style={{ fontSize: 22, lineHeight: 1 }}>{emoji}</span>
        <span style={{ fontSize: 9, fontWeight: activeScreen === key ? 700 : 400 }}>{label}</span>
      </button>
    );
  };

  return (
    <nav style={{
      background: 'linear-gradient(180deg, rgba(20,10,0,0.97), rgba(10,5,0,0.99))',
      borderTop: '1px solid rgba(244,208,63,0.15)',
      display: 'flex', flexDirection: 'column',
      flexShrink: 0,
      boxShadow: '0 -4px 20px rgba(0,0,0,0.6)',
    }}>
      {/* Row 1 */}
      <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
        {ROW1.map(renderTab)}
      </div>
      {/* Row 2 */}
      <div style={{ display: 'flex' }}>
        {ROW2.map(renderTab)}
      </div>
    </nav>
  );
}
