export interface Cost { gold: number; wood: number; stone: number; }

export const BUILDING_BASE_COSTS: Record<string, Cost> = {
  town_hall:    { gold: 500, wood: 200, stone: 200 },
  gold_mine:    { gold: 200, wood: 100, stone: 0   },
  lumber_mill:  { gold: 150, wood: 0,   stone: 100 },
  stone_quarry: { gold: 150, wood: 100, stone: 0   },
  farm:         { gold: 100, wood: 150, stone: 0   },
  barracks:     { gold: 300, wood: 200, stone: 100 },
  academy:      { gold: 500, wood: 300, stone: 200 },
  wall:         { gold: 200, wood: 0,   stone: 400 },
  watch_tower:  { gold: 150, wood: 200, stone: 100 },
  hospital:     { gold: 400, wood: 200, stone: 200 },
  arcane_tower: { gold: 600, wood: 300, stone: 300 },
};

const GROWTH = 1.35;

// Cost to upgrade a building from `currentLevel` to `currentLevel + 1`.
export function upgradeCost(type: string, currentLevel: number): Cost {
  const base = BUILDING_BASE_COSTS[type] || { gold: 0, wood: 0, stone: 0 };
  const mult = Math.pow(GROWTH, currentLevel);
  return {
    gold:  Math.floor(base.gold  * mult),
    wood:  Math.floor(base.wood  * mult),
    stone: Math.floor(base.stone * mult),
  };
}

export const RESOURCE_META: Record<keyof Cost, { emoji: string; color: string }> = {
  gold:  { emoji: '💰', color: '#f4d03f' },
  wood:  { emoji: '🪵', color: '#b07a45' },
  stone: { emoji: '🪨', color: '#b8c0c4' },
};
